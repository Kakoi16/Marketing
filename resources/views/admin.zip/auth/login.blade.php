{{-- resources/views/auth/login.blade.php --}}
<x-guest-layout>
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <h2 class="mb-3 text-3xl font-bold">SELAMAT DATANG!</h2>
    <p class="mb-6 font-light text-gray-500">
        Masuk ke akun Anda untuk melanjutkan.
    </p>

    <form action="{{ route('login') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label for="email" class="block mb-2 text-sm font-medium text-gray-700">Alamat Email</label>
                        <input type="email" id="email" name="email" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                               placeholder="contoh@gmail.com">
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="block mb-2 text-sm font-medium text-gray-700">Kata Sandi</label>
                        <input type="password" id="password" name="password" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                               placeholder="Masukan Kata Sandi">
                    </div>

                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center">
                            <input id="remember_me" name="remember" type="checkbox" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                            <label for="remember_me" class="ml-2 text-sm text-gray-700">Ingat Saya</label>
                        </div>
                        <a href="#" class="text-sm text-blue-600 hover:underline">Lupa Kata Sandi?</a>
                    </div>
                    
                    <button type="submit"
                            class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all duration-300 ease-in-out">
                        Login
                    </button>
                    
                    <div class="mt-6 text-center">
                        <a href="{{ route('register') }}" class="text-sm text-gray-500 hover:text-blue-600 hover:underline">
                            Belum punya akun? Daftar
                        </a>
                    </div>
                </form>
</x-guest-layout>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const isMobile = window.innerWidth < 768;

    const driver = new Driver({
        animate: true,
        opacity: 0.75,
        padding: 8,
        allowClose: false,
        stageBackground: '#ffffff',
    });

    driver.defineSteps([
        {
            element: '#email',
            popover: {
                title: 'Masukkan Email Anda',
                description: 'Gunakan email yang telah terdaftar pada akun Anda.',
                position: isMobile ? 'bottom' : 'right'
            }
        },
        {
            element: '#password',
            popover: {
                title: 'Masukkan Kata Sandi',
                description: 'Pastikan kata sandi yang Anda masukkan sudah benar.',
                position: isMobile ? 'bottom' : 'right'
            }
        },
        {
            element: 'button[type="submit"]',
            popover: {
                title: 'Klik Login',
                description: 'Setelah semua data terisi, klik tombol ini untuk masuk.',
                position: 'top'
            }
        }
    ]);

    driver.start();
});
</script>