<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pembayaran</title>
    <script src="https://cdn.tailwindcss.com"></script>
    {{-- Tambahkan Alpine.js untuk fungsionalitas Salin --}}
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gray-100">

    <div id="app">
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Dashboard Pembayaran
                </h2>
                {{-- Tambahkan Tombol Logout --}}
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <a href="{{ route('logout') }}"
                            onclick="event.preventDefault(); this.closest('form').submit();"
                            class="text-sm text-gray-600 hover:text-gray-900">
                        Logout
                    </a>
                </form>
            </div>
        </header>

      {{-- ... (kode <head> dan <header> Anda) ... --}}

<main>
    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">

            {{-- ... (kode session('success')) ... --}}

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    {{-- =================== TAMBAHKAN BLOK INI =================== --}}
                    @isset($error_message)
                        <div class="text-center p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50" role="alert">
                            <span class="font-bold">Terjadi Kesalahan!</span>
                            <p class="mt-1">{{ $error_message }}</p>
                        </div>
                    @else
                    {{-- ========================================================== --}}
                        
                        <div class="text-center mb-4">
                            <h3 class="text-2xl font-bold text-gray-800">Selesaikan Pembayaran Anda</h3>
                            <p class="text-gray-600">Gunakan detail di bawah ini untuk membayar biaya pendaftaran.</p>
                        </div>

                        {{-- Cek jika data user ada --}}
                        @if($user)
                            {{-- ... (Seluruh kode detail VA Anda) ... --}}
                            <div class="border rounded-lg p-6 space-y-4" x-data="{ copied: false }">
                                {{-- Detail Total Pembayaran --}}
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-500">Total Pembayaran:</span>
                                    <span class="font-bold text-xl text-indigo-600">
                                        Rp {{ number_format($user->va_amount, 0, ',', '.') }}
                                    </span>
                                </div>
                                <hr>
                                {{-- Detail Nomor Virtual Account --}}
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-500">Nomor Virtual Account:</span>
                                    <div class="flex items-center space-x-2">
                                        <span id="va-number" class="font-semibold text-gray-800">{{ $user->va_number }}</span>
                                        <button @click="navigator.clipboard.writeText('{{ $user->va_number }}'); copied = true; setTimeout(() => copied = false, 2000);"
                                                class="text-sm p-1 rounded hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                                        </button>
                                        <span x-show="copied" x-transition class="text-xs text-green-600">Disalin!</span>
                                    </div>
                                </div>
                                {{-- Detail Batas Waktu --}}
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-500">Batas Waktu Pembayaran:</span>
                                    <span class="font-semibold text-red-500">
                                        {{ \Carbon\Carbon::parse($user->va_expired_at)->translatedFormat('d F Y, H:i') }} WIB
                                    </span>
                                </div>
                            </div>
                        @endif
                        
                        <div class="mt-6">
                            <h4 class="font-semibold text-gray-700">Cara Pembayaran:</h4>
                            {{-- ... (kode cara pembayaran) ... --}}
                        </div>
                        
                    {{-- =================== TUTUP BLOK @else =================== --}}
                    @endisset
                    {{-- ======================================================= --}}
                </div>
            </div>
        </div>
    </div>
</main>
{{-- ... (sisa kode) ... --}}
    </div>

</body>
</html>