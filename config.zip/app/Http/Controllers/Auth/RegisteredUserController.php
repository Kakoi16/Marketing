<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\BNIApiService;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Log;
use Exception;

class RegisteredUserController extends Controller
{
    public function create()
    {
        return view('auth.register');
    }

    /**
     * Handle registration request safely.
     */
    public function store(Request $request, BNIApiService $bniService): RedirectResponse
    {
        set_time_limit(60);

        Log::info('📥 Menerima request register', $request->all());

        //try {
            // PERUBAHAN 1: Menambahkan validasi regex untuk format 08...
            $validated = $request->validate([
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 
                // 'unique:users,email'
            ],
                'phone' => [
                    'required',
                    // 'unique:users,phone',
                    'regex:/^08[0-9]{8,11}$/' 
                ],
                'password' => ['required', 'confirmed', Rules\Password::defaults()],
            ]);

            Log::info('✅ Validasi sukses', $validated);
            $normalizedPhone = $validated['phone'];
            if (str_starts_with($normalizedPhone, '08')) {
                $normalizedPhone = '62' . substr($normalizedPhone, 1);
            }

            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'phone' => $normalizedPhone, // Menggunakan nomor yang sudah diubah ke 62
                'password' => Hash::make($validated['password']),
                'role' => 'mahasiswa_baru',
            ]);

            Log::info('✅ User berhasil dibuat', ['id' => $user->id, 'phone' => $normalizedPhone]);
            
            event(new Registered($user));
            Auth::login($user);

            $amount = 300000;
            Log::info('💰 Membuat VA', ['user_id' => $user->id, 'amount' => $amount]);

                $response = $bniService->createBilling($user, $amount);
                // dd($response);
                Log::info('📦 Respons API BNI', ['response' => $response]);

                 if (isset($response['virtual_account']) && !empty($response['virtual_account'])) {
            $user->update([
                'va_number' => $response['virtual_account'],
                'va_expired_at' => $response['datetime_expired'] ?? now()->addDays(1),
                'va_amount' => $amount,
            ]);

            Log::info("✅ VA berhasil dibuat untuk user {$user->id}");
        } else {
            // Simpan pesan error jika gagal
            Log::warning('⚠️ Respons VA kosong / tidak valid', ['response' => $response]);
            $user->update(['va_status' => 'FAILED']);
        }
        
$user->refresh();
            // Redirect ke dashboard
            return redirect()
                ->route('mahasiswa.va.dashboard')
                ->with('success', 'Registrasi berhasil! Silakan lanjut ke dashboard untuk melihat Virtual Account Anda.');

    }
}